package com.exam.controller;

import java.time.LocalDate;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import com.exam.model.Exam;
import com.exam.model.Question;
import com.exam.model.Result;
import com.exam.model.User;
import com.exam.repo.ExamBo;
import com.exam.repo.QuestionBo;
import com.exam.repo.ResultBo;
import com.exam.repo.UserBo;
import com.exam.service.ExamService;
import jakarta.servlet.http.HttpServletRequest;

@RestController
public class EMSController {
    @Autowired
    ExamService es;
    
    @Autowired
    ExamBo eb;
    
    @Autowired
    UserBo ub;
    
    @Autowired
    QuestionBo qb;
    
    @Autowired
    ResultBo rb;
    
	@RequestMapping("/")
	public ModelAndView m1() {
		return new ModelAndView("index");
	}
	
	@RequestMapping(value="insertexam", method=RequestMethod.POST)
	public ModelAndView m4(HttpServletRequest req) {
		ModelAndView mv = null;
		String exam_title=req.getParameter("examtitle");
		LocalDate ld = LocalDate.parse(req.getParameter("examdatetime"));
		String exam_duration=req.getParameter("examduration");
		String total_quest=req.getParameter("totalquestion");
		String rightanswer=req.getParameter("rightanswer");
		String wronganswer=req.getParameter("wronganswer");
		String standard=req.getParameter("standard");
		
		Exam ex = new Exam(0,exam_title,ld,exam_duration,total_quest,rightanswer,wronganswer,standard);
		try {
			es.insertExam(ex);
		    mv= new ModelAndView("success");
		    mv.addObject("msg","Exam Added Successfully");
		}
		catch(Exception e) {
			mv= new ModelAndView("error");
		}
		return mv;
	}
	
	@RequestMapping("/addExam")
	public ModelAndView addExam() {
		return new ModelAndView("addExam");
	}
	
	@RequestMapping("/teacherdashboard")
	public ModelAndView teacherDashboard() {
		return new ModelAndView("teacherdashboard");
	}
	
	@RequestMapping("/viewexam")
	public ModelAndView getAllExam() {
		ModelAndView mv = new ModelAndView("viewexam");
		List<Exam> li = es.getAllExam();
		mv.addObject("exams",li);
		return mv;
	}
	
	@RequestMapping("/updateexam")
	public ModelAndView updateExam(HttpServletRequest req) {
		ModelAndView mv = new ModelAndView("updateexam");
		int id = Integer.parseInt(req.getParameter("id"));
		Exam e = es.getExamById(id);
		mv.addObject("exams", e);
		return mv;
	}
	
	@RequestMapping(value="updateexamdetails", method=RequestMethod.POST)
	public ModelAndView updateExamDetails(HttpServletRequest req) {
		ModelAndView mv = null;
		String exam_title=req.getParameter("examtitle");
		LocalDate ld = LocalDate.parse(req.getParameter("examdatetime"));
		String exam_duration=req.getParameter("examduration");
		String total_quest=req.getParameter("totalquestion");
		String rightanswer=req.getParameter("rightanswer");
		String wronganswer=req.getParameter("wronganswer");
		String standard=req.getParameter("standard");
		
		Exam ex = new Exam(Integer.parseInt(req.getParameter("mid")),exam_title,ld,exam_duration,total_quest,rightanswer,wronganswer,standard);
		try {
			es.updateExam(ex);
		    mv= new ModelAndView("success");
		    mv.addObject("msg","Exam Updated Successfully");
		}
		catch(Exception e) {
			mv= new ModelAndView("error");
		}
		return mv;
	}
	
	@RequestMapping("deleteExam")
	public ModelAndView deleteExam(HttpServletRequest req) {
		ModelAndView mv = new ModelAndView("success");
		es.deleteExam(Integer.parseInt(req.getParameter("id")));
		mv.addObject("msg","Exam Deleted Successfully");
		return mv;
	}
	
	@RequestMapping("/registerStudent")
	public ModelAndView registerStudent() {
		return new ModelAndView("register");
	}
	
	@RequestMapping("/insertUser")
	public ModelAndView insertUser(HttpServletRequest req) {
		ModelAndView mv = null;
		String email = req.getParameter("email");
		String name = req.getParameter("name");
		String standard=req.getParameter("standard");
		String gender=req.getParameter("gender");
		String location = req.getParameter("location");
		String password = req.getParameter("password");
		
		User u1 = new User(email,name,standard,gender,location,password);
		try {
			ub.save(u1);
		    mv= new ModelAndView("studentLogin");
		}
		catch(Exception e) {
			mv= new ModelAndView("error");
		}
		return mv;
	}
	
	@RequestMapping("/studentLogin")
	public ModelAndView studentLogin() {
		return new ModelAndView("studentLogin");
	}
	
	@RequestMapping("/teacherLogin")
	public ModelAndView teacherLogin() {
		return new ModelAndView("teacherLogin");
	}
	
	@RequestMapping("checkteacher")
	public ModelAndView checkTeacher(HttpServletRequest req) {
		ModelAndView mv = null;
		String email =req.getParameter("username");
		String password =req.getParameter("password");
		
		if(email.equals("admin")&& password.equals("admin")) {
			mv= new ModelAndView("teacherdashboard");
		}
		else {
			mv = new ModelAndView("teacherLogin");
		}
		return mv;
	}
	
	@RequestMapping("checkstudent")
	public ModelAndView checkStudent(HttpServletRequest req){
		ModelAndView mv=new ModelAndView("studentLogin");
		String email1=req.getParameter("username");
		String password = req.getParameter("password");
		User u1=ub.getById(email1);
		if(email1.equals(u1.getEmail())) {
			if(password.equals(u1.getPassword())) {
				mv = new ModelAndView("welcomeuser");
				mv.addObject("name",u1.getName());
				mv.addObject("standard",u1.getStandard());
				mv.addObject("studentEmail",u1.getEmail());
			}
			else {
				mv= new ModelAndView("studentLogin");
			}
		}
		else {
			mv= new ModelAndView("studentLogin");
		}
		return mv;
	}
	
	@RequestMapping("/viewstudentexam")
	public ModelAndView viewStudentExam(HttpServletRequest req) {
		ModelAndView mv = new ModelAndView("viewstudentexam");
		String standard = req.getParameter("standard");
		String studentEmail = req.getParameter("studentEmail");
		List<Exam> exam = eb.getByStandard(standard);
		List<Result> studentResults = rb.findByStudentEmail(studentEmail);
		mv.addObject("exams",exam);
		mv.addObject("studentEmail",studentEmail);
		mv.addObject("studentResults",studentResults);
		return mv;
	}
	
	@RequestMapping("/addQuestion")
	public ModelAndView addQuestion(HttpServletRequest req) {
		ModelAndView mv = new ModelAndView("addQuestion");
		mv.addObject("examId", req.getParameter("examId"));
		return mv;
	}
	
	@RequestMapping(value="insertQuestion", method=RequestMethod.POST)
	public ModelAndView insertQuestion(HttpServletRequest req) {
		ModelAndView mv = null;
		int examId = Integer.parseInt(req.getParameter("examId"));
		String questionText = req.getParameter("questionText");
		String optionA = req.getParameter("optionA");
		String optionB = req.getParameter("optionB");
		String optionC = req.getParameter("optionC");
		String optionD = req.getParameter("optionD");
		String correctAnswer = req.getParameter("correctAnswer");
		
		Question q = new Question(examId, questionText, optionA, optionB, optionC, optionD, correctAnswer);
		try {
			qb.save(q);
			mv = new ModelAndView("success");
			mv.addObject("msg", "Question Added Successfully");
		} catch(Exception e) {
			mv = new ModelAndView("error");
		}
		return mv;
	}
	
	@RequestMapping("/startExam")
	public ModelAndView startExam(HttpServletRequest req) {
		int examId = Integer.parseInt(req.getParameter("examId"));
		String studentEmail = req.getParameter("studentEmail");
		
		// Check if student has already attempted this exam
		List<Result> existingResults = rb.findByStudentEmail(studentEmail);
		for(Result result : existingResults) {
			if(result.getExamId() == examId) {
				ModelAndView mv = new ModelAndView("examRestricted");
				mv.addObject("message", "You have already attempted this assessment.");
				return mv;
			}
		}
		
		ModelAndView mv = new ModelAndView("examAttempt");
		Exam exam = es.getExamById(examId);
		List<Question> questions = qb.findByExamId(examId);
		mv.addObject("exam", exam);
		mv.addObject("questions", questions);
		mv.addObject("studentEmail", studentEmail);
		return mv;
	}
	
	@RequestMapping(value="submitExam", method=RequestMethod.POST)
	public ModelAndView submitExam(HttpServletRequest req) {
		ModelAndView mv = null;
		int examId = Integer.parseInt(req.getParameter("examId"));
		String studentEmail = req.getParameter("studentEmail");
		List<Question> questions = qb.findByExamId(examId);
		
		int score = 0;
		for(Question q : questions) {
			String userAnswer = req.getParameter("answer_" + q.getQuestionId());
			if(userAnswer != null && userAnswer.equals(q.getCorrectAnswer())) {
				score++;
			}
		}
		
		Result result = new Result(studentEmail, examId, score, questions.size());
		try {
			rb.save(result);
			mv = new ModelAndView("examResult");
			mv.addObject("result", result);
		} catch(Exception e) {
			mv = new ModelAndView("error");
		}
		return mv;
	}
	
	@RequestMapping("/viewResults")
	public ModelAndView viewResults(HttpServletRequest req) {
		ModelAndView mv = new ModelAndView("viewResults");
		String studentEmail = req.getParameter("studentEmail");
		List<Result> results = rb.findByStudentEmail(studentEmail);
		List<Exam> allExams = es.getAllExam();
		mv.addObject("results", results);
		mv.addObject("exams", allExams);
		return mv;
	}
	
	@RequestMapping("/viewAllResults")
	public ModelAndView viewAllResults() {
		ModelAndView mv = new ModelAndView("viewAllResults");
		List<Result> allResults = rb.findAll();
		mv.addObject("results", allResults);
		return mv;
	}
}