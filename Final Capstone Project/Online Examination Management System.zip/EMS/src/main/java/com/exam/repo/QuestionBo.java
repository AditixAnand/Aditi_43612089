package com.exam.repo;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.exam.model.Question;

@Repository
public interface QuestionBo extends JpaRepository<Question, Integer> {
    @Query(value = "SELECT * FROM question WHERE exam_id = :examId", nativeQuery = true)
    List<Question> findByExamId(@Param("examId") int examId);
}