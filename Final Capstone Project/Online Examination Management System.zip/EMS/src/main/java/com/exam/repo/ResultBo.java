package com.exam.repo;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.exam.model.Result;

@Repository
public interface ResultBo extends JpaRepository<Result, Integer> {
    @Query(value = "SELECT * FROM result WHERE student_email = :email", nativeQuery = true)
    List<Result> findByStudentEmail(@Param("email") String email);
}